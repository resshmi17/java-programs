import java.util.*;
public class Main
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.nextLine();
	System.out.print("[");
	String s1="";
	for(int i=0;i<s.length();i++)
	{
	    if(s.charAt(i)!='a')
	    s1=s1+s.charAt(i);
	    else
	    {
	  
	    
	    System.out.print(s1+",");
	    s1="";
	    continue;
	    }
	    
	}
	System.out.print(s1);
	System.out.print("]");
	}
}