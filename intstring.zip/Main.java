import java.util.*;
import java.io.*;
public class Main
{
	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
String s=Integer.toString(n);
int r=s.length();
for(int i=0;i<=r;i++){
System.out.println(s[i]);
}
	}
}
