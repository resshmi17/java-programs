import java.util.*;
import java.io.*;
public class Main{  
public static void main(String args[]){  
   Scanner sc=new Scanner(System.in);
String s=sc.nextLine();
String v="";
String c="";
char[]a=new char[s.length()];
char[]b=new char[s.length()];
for(int i=0; i<s.length();i++){  
if(s.charAt(i)=='A'||s.charAt(i)=='E'||s.charAt(i)=='I'||s.charAt(i)=='O'||s.charAt(i)=='U'||s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u')
v=v+s.charAt(i);

else
c=c+s.charAt(i);
}
System.out.println(v);
System.out.print(c);

}
}
