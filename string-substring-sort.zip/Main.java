import java.util.*;
class Main{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        String s=sc.nextLine();
        int n=sc.nextInt();
        int r=s.length()-n+1;
        String str[]=new String[r];
        if(s.length()<n){
            System.out.println("cannot perform");
        }
        for(int i=0;i<r;i++){
            str[i]=s.substring(i,i+n);
           
        }
         Arrays.sort(str);
        
          System.out.println(str[0]);
           System.out.println(str[r-1]);
        
    }
}