import java.util.*;
import java.io.*;
public class Main
{
	public static void main(String[] args){
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
int c=0,r;
for(int i=0;i<=n;i++,  r=n%10,
    c++,
    n=n/10){
        System.out.println(c);
  
}

}
}