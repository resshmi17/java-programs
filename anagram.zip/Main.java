import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        String b = sc.nextLine();
        int arr[] = new int[26];
        int k = 1;
        if (a.length() != b.length()) {
            System.out.println("not an anagram");
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            k = a.charAt(i) - 97;
            arr[k]++;
        }
        for (int j = 0; j < b.length(); j++) {
            k = b.charAt(j) - 97;
            arr[k]--;
        }
        for (int i = 0; i < 26; i++) {
            if (arr[i] != 0) {
                System.out.println("not an anagram");
                return;  // Exit early if not an anagram
            }
        }
        System.out.println("anagram");  // Only print this if no mismatch is found
    }
}