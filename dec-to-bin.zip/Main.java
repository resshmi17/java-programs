import java.io.*;
import java.util.*;
public class Main{
public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt(),s=0,b=1;
		while(n!=0){
		   s+=(n%2)*b;
		   b*=10;
		   n/=2;
		}
		System.out.println(s);
}
}

