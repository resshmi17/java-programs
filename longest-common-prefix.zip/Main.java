import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        sc.nextLine(); 

        String[] str = new String[n];
        for (int i = 0; i < n; i++) {
            str[i] = sc.nextLine();
        }
        Arrays.sort(str);

        String small = str[0];
        String large = str[n - 1];
        String a = "";
        int minLength = Math.min(small.length(), large.length());
        for (int i = 0; i < minLength; i++) {
            if (small.charAt(i) != large.charAt(i)) {
                break;
            }
            a += small.charAt(i); 
        }

        System.out.println(a);
    }
}

