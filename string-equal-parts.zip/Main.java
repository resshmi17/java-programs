import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String a = sc.nextLine();
        int len = a.length();
        int div = sc.nextInt();
        int chars = len / div;
        if (len % div != 0) {
            System.out.println("Can't divide the string into " + div + " equal parts.");
        } else {
            // Loop to print each part of the string
            for (int i = 0; i < len; i += chars) {
                String c = a.substring(i, i + chars);
                System.out.println(c);
            }
        }
    }
}
